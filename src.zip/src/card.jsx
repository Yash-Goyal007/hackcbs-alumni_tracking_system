import React from 'react';
import './card.css';

function Card(props){
    return(
        <div className="card">
            <img src={props.src} alt="" />
            <h3>{props.name}</h3>
            <span>{props.position}</span>
        </div>
    );
}

export default Card;
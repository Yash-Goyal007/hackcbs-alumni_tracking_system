import React from 'react';
import './cardrow.css';
import Card from './card.jsx';

function Cardrow2(){
    return(
        <div className="cardrow">
            <Card name='Virat Kohli' position='Cricketer' src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpnUmAuCguDsJ2wd163SI_UeAoYAVTPOgIGQ&usqp=CAU'/>
            <Card name='Raskin Bobbins' position='Biggest Ice-cream Company' src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIGJveXqHmpYlf07mFvWKzi2gEaXjLVbLTNQ&usqp=CAU'/>
        </div>
    );
}

export default Cardrow2;
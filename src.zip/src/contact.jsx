import React from 'react';
import './contact.css';

function Contact(){
    return(
        <div className="contact">
            <span>Name</span>
            <input type="text" />
            <span>Email</span>
            <input type="email" />
            <span>Address</span>
            <input type="text" />
            <span>Subject</span>
            <textarea name="" id="" cols="30" rows="10"></textarea>
            <span className='contact-submit'>Submit Now</span>
        </div>
    );
}

export default Contact;
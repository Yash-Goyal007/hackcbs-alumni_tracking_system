import React from 'react';
import './footer.css';

function Footer(){
    return(
        <div className="footer">
            Copyright &copy; 2022. All Rights Reserved
        </div>
    );
}

export default Footer;
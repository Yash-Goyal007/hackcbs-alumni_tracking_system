import React from 'react';
import './eventcard.css';

function EventCard(props){
    return(
        <div className="eventcard">
            <img src={props.src} alt="" />
            <span>Date</span>
            <span>Time</span>
            <span>Venue</span>
            <span>Ticket</span>
        </div>
    );
}

export default EventCard;
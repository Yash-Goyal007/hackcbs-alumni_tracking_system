import React from 'react';
import './App.css';
import Home from './home.jsx';
import Footer from './footer.jsx';
import Navbar from './navbar.jsx';
import Opportunities from './opportunities.jsx';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Contact from './contact.jsx';
import Community from './community.jsx';
import Banner from './banner.jsx';
import About from './about.jsx';
import Alumni from './alumni.jsx'


function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route exact path='/opportunities'>
            <Navbar />
            <Opportunities />
            <hr />
            <Banner />
            <hr />
            <Footer />
          </Route>
          <Route path='/about'>
            <Navbar />
            <About />
            <hr />
            <Banner />
            <hr />
            <Footer />
          </Route>
          <Route path='/alumni'>
            <Navbar />
            <Alumni />
            <hr />
            <Banner />
            <hr />
            <Footer />
          </Route>
          <Route exact path='/contact'>
            <Navbar />
            <Contact />
            <hr />
            <Banner />
            <hr />
            <Footer />
          </Route>
          <Route exact path='http://127.0.0.1:8000/'>
            <Navbar />
            <Community />
            <hr />
            <Banner />
            <hr />
            <Footer />
          </Route>
          <Route path='/'>
            <Navbar />
            <Home />
            <hr />
            <Banner />
            <hr />
            <Footer />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;

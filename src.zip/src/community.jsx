import React from 'react';

function Community(){
    return(
        <div className="community">
            
        </div>
    )
};

export default Community;
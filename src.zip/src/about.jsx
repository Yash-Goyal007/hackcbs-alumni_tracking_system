import React from 'react';
import './about.css';

function About() {
    return (
        <div className="about">
            <span>About Us</span>
            <p>Indian people are in utter need of self-run trustworthy connection platforms. It provides a secure community of our Alumni. It gives us access to job referrals and internships opportunities in a preferential manner.  An interconnected alumni network, where they can help each other and provide mentorship to the younger members of the community. It helps various college committees to look for grants or organise fund-raising platforms.</p>
        </div>
    );
}

export default About;
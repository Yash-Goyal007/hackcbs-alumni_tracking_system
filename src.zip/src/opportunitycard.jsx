import React from 'react';
import './opportunitycard.css';

function OpportunityCard(props){
    return(
        <div className="opportunitycard">
            <div className="card-left">
                <img src={props.src} alt="" />
                <span>Offered by: </span>
            </div>
            <div className="card-right">
                <span>Title: {props.title}</span>
                <span>Skills Required: {props.skills}</span>
                <span>Company: {props.company}</span>
                <span>Salary: {props.salary}</span>
                <span>Description: {props.description}</span>
                <span>Apply Here</span>
            </div>
        </div>
    );
}

export default OpportunityCard;